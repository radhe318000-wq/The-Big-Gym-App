Copy your gym lion logo to gym_logo.png and BharatPe QR to bharatpe_qr.png. These filenames are referenced by MainActivity.kt.
