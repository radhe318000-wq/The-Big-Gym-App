package com.thebiggym.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions

private val Gold = Color(0xFFF5C400)
private val Black = Color(0xFF101010)
private val SurfaceDark = Color(0xFF1B1B1B)
private val Muted = Color(0xFFBDBDBD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Gold,
                    onPrimary = Black,
                    background = Black,
                    surface = SurfaceDark,
                    onSurface = Color.White
                )
            ) { GymApp() }
        }
    }
}

private enum class Screen { LOGIN, MEMBER, OWNER, ADD_MEMBER, QR }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GymApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    val functions = remember { FirebaseFunctions.getInstance() }

    var screen by remember { mutableStateOf(Screen.LOGIN) }
    var memberId by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var ownerMode by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var profile by remember { mutableStateOf<Map<String, Any>?>(null) }
    var memberName by remember { mutableStateOf("") }
    var memberPhone by remember { mutableStateOf("") }
    var plan by remember { mutableStateOf("Monthly") }
    var amount by remember { mutableStateOf("1000") }
    var joining by remember { mutableStateOf("") }
    var expiry by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }

    fun login() {
        val id = memberId.trim().uppercase()
        if (id.isBlank() || password.isBlank()) {
            status = "Enter Membership ID and password."
            return
        }
        busy = true
        status = ""
        // Auth aliases are generated server-side; users must not choose arbitrary email addresses.
        val email = if (ownerMode) memberId.trim() else "${id.lowercase()}@members.thebiggym.app"
        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                val user = auth.currentUser
                if (user == null) {
                    busy = false
                    status = "Login failed. Please try again."
                    return@addOnSuccessListener
                }
                user.getIdToken(true).addOnSuccessListener { token ->
                    val role = token.claims["role"] as? String
                    if (ownerMode) {
                        if (role == "owner") {
                            screen = Screen.OWNER
                            status = ""
                        } else {
                            auth.signOut()
                            status = "This account is not authorized as an owner."
                        }
                        busy = false
                    } else {
                        db.collection("members").document(user.uid).get()
                            .addOnSuccessListener { doc ->
                                profile = doc.data
                                if (doc.exists() && doc.getString("membershipId") == id &&
                                    doc.getString("status") != "deleted") {
                                    screen = Screen.MEMBER
                                } else {
                                    auth.signOut()
                                    status = "Member record not found. Contact the gym owner."
                                }
                                busy = false
                            }.addOnFailureListener {
                                auth.signOut()
                                status = "Could not load member details. Check connection."
                                busy = false
                            }
                    }
                }.addOnFailureListener {
                    auth.signOut()
                    status = "Could not verify account permissions."
                    busy = false
                }
            }.addOnFailureListener {
                busy = false
                status = "Login failed. Check your ID/password or internet connection."
            }
    }

    fun logout() {
        auth.signOut()
        profile = null
        password = ""
        screen = Screen.LOGIN
        ownerMode = false
        status = ""
    }

    Scaffold(
        containerColor = Black,
        topBar = {
            if (screen != Screen.LOGIN) {
                TopAppBar(
                    title = { Text("THE BIG GYM", color = Gold, fontWeight = FontWeight.Black) },
                    navigationIcon = {
                        IconButton(onClick = {
                            when (screen) {
                                Screen.ADD_MEMBER -> screen = Screen.OWNER
                                Screen.QR -> screen = if (ownerMode) Screen.OWNER else Screen.MEMBER
                                else -> logout()
                            }
                        }) { Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Gold) }
                    },
                    actions = { TextButton(onClick = { logout() }) { Text("Logout", color = Gold) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Black)
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding)
                .verticalScroll(rememberScrollState()).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (screen == Screen.LOGIN) {
                Spacer(Modifier.height(20.dp))
                // Add gym_logo.png to drawable to show your supplied logo.
                runCatching { painterResource(R.drawable.gym_logo) }.getOrNull()?.let {
                    Image(it, contentDescription = "The BIG Gym logo", modifier = Modifier.size(125.dp))
                }
                Text("THE BIG GYM", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text("DISCIPLINE  |  DEDICATION  |  FOCUS  |  ENERGY", color = Muted, fontSize = 11.sp)
                Text(if (ownerMode) "OWNER LOGIN" else "MEMBER LOGIN", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = memberId, onValueChange = { memberId = it },
                    label = { Text(if (ownerMode) "Owner email" else "Membership ID") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = password, onValueChange = { password = it },
                    label = { Text("Password") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = { login() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text(if (busy) "PLEASE WAIT…" else "LOGIN", fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = {
                    ownerMode = !ownerMode
                    memberId = ""; password = ""; status = ""
                }) {
                    Text(if (ownerMode) "Member login instead" else "Owner login", color = Gold)
                }
                if (status.isNotBlank()) Text(status, color = Color(0xFFFF8A80))
                Spacer(Modifier.height(24.dp))
                Text("Member records are private. Use the credentials supplied by the gym owner.", color = Muted, fontSize = 12.sp)
            }

            if (screen == Screen.MEMBER) {
                Text("MY MEMBERSHIP", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                val p = profile.orEmpty()
                DetailRow("Name", p["name"]?.toString() ?: "—")
                DetailRow("Membership ID", p["membershipId"]?.toString() ?: "—")
                DetailRow("Phone", p["phone"]?.toString() ?: "—")
                DetailRow("Plan", p["plan"]?.toString() ?: "—")
                DetailRow("Joining date", p["joiningDate"]?.toString() ?: "—")
                DetailRow("Expiry date", p["expiryDate"]?.toString() ?: "—")
                DetailRow("Monthly fee", "₹${p["feeAmount"]?.toString() ?: "—"}")
                val paid = p["feeStatus"]?.toString() == "paid"
                DetailRow("Fee status", if (paid) "PAID" else "PENDING")
                Button(onClick = { screen = Screen.QR }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.QrCode2, contentDescription = null)
                    Spacer(Modifier.width(8.dp)); Text("PAY FEES")
                }
                Text("After paying, wait for the owner to verify and update your status.", color = Muted, fontSize = 12.sp)
            }

            if (screen == Screen.QR) {
                Text("PAY THE BIG GYM", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("Scan this BharatPe QR with any UPI app. Confirm the recipient before paying.", color = Color.White)
                runCatching { painterResource(R.drawable.bharatpe_qr) }.getOrNull()?.let {
                    Image(it, contentDescription = "BharatPe payment QR", modifier = Modifier.fillMaxWidth().padding(8.dp))
                }
                Text("Payment is not automatically confirmed in this app. The owner will update your fee status after checking BharatPe.", color = Muted, fontSize = 12.sp)
            }

            if (screen == Screen.OWNER) {
                Text("OWNER DASHBOARD", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("Use this panel to manage members and record payments.", color = Muted)
                Button(onClick = { screen = Screen.ADD_MEMBER }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.FitnessCenter, contentDescription = null)
                    Spacer(Modifier.width(8.dp)); Text("ADD MEMBER")
                }
                var searchId by remember { mutableStateOf("") }
                OutlinedTextField(value = searchId, onValueChange = { searchId = it.uppercase() },
                    label = { Text("Find member by ID") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    if (searchId.isBlank()) { status = "Enter a Membership ID."; return@Button }
                    busy = true
                    functions.getHttpsCallable("getMemberForOwner").call(mapOf("membershipId" to searchId.trim()))
                        .addOnSuccessListener { result ->
                            val data = result.data as? Map<*, *>
                            val uid = data?.get("uid") as? String
                            if (uid == null) {
                                status = "Member not found."
                            } else {
                                db.collection("members").document(uid).get().addOnSuccessListener { doc ->
                                    profile = doc.data
                                    status = if (doc.exists()) "Selected ${doc.getString("membershipId")}" else "Member not found."
                                }.addOnFailureListener { status = "Could not load member." }
                            }
                            busy = false
                        }.addOnFailureListener {
                            status = "Lookup failed. Check Firebase Functions setup."
                            busy = false
                        }
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("SEARCH MEMBER") }

                profile?.let { p ->
                    Divider(color = Gold)
                    Text("${p["name"] ?: "Member"} · ${p["membershipId"] ?: ""}", color = Color.White, fontWeight = FontWeight.Bold)
                    DetailRow("Plan", p["plan"]?.toString() ?: "—")
                    DetailRow("Fee status", p["feeStatus"]?.toString() ?: "pending")
                    Button(onClick = {
                        val id = p["membershipId"]?.toString() ?: ""
                        functions.getHttpsCallable("markFeesPaid").call(mapOf(
                            "membershipId" to id,
                            "amount" to (p["feeAmount"]?.toString() ?: "0"),
                            "method" to "BharatPe/UPI"
                        )).addOnSuccessListener {
                            status = "Payment recorded for $id."
                            db.collection("members").whereEqualTo("membershipId", id).get()
                                .addOnSuccessListener { snap -> profile = snap.documents.firstOrNull()?.data }
                        }.addOnFailureListener { status = "Could not record payment. Check owner permissions." }
                    }, modifier = Modifier.fillMaxWidth()) { Text("MARK FEES PAID (VERIFIED)") }
                }
                if (status.isNotBlank()) Text(status, color = if (status.contains("failed", true)) Color(0xFFFF8A80) else Gold)
            }

            if (screen == Screen.ADD_MEMBER) {
                Text("ADD NEW MEMBER", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(memberName, { memberName = it }, label = { Text("Full name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(memberPhone, { memberPhone = it }, label = { Text("Phone number") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(plan, { plan = it }, label = { Text("Plan (e.g. Monthly)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(amount, { amount = it }, label = { Text("Fee amount ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(joining, { joining = it }, label = { Text("Joining date (DD/MM/YYYY)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(expiry, { expiry = it }, label = { Text("Expiry date (DD/MM/YYYY)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(newPassword, { newPassword = it }, label = { Text("Temporary member password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    if (memberName.isBlank() || amount.toDoubleOrNull() == null || newPassword.length < 8) {
                        status = "Enter name, valid fee and a password of at least 8 characters."
                        return@Button
                    }
                    busy = true
                    functions.getHttpsCallable("createMember").call(mapOf(
                        "name" to memberName.trim(), "phone" to memberPhone.trim(),
                        "plan" to plan.trim(), "feeAmount" to amount.toDouble(),
                        "joiningDate" to joining.trim(), "expiryDate" to expiry.trim(),
                        "password" to newPassword
                    )).addOnSuccessListener { result ->
                        val data = result.data as? Map<*, *>
                        status = "Created member ${data?.get("membershipId") ?: ""}. Share the ID and temporary password privately."
                        memberName = ""; memberPhone = ""; newPassword = ""
                        busy = false
                    }.addOnFailureListener {
                        status = "Could not create member. Check Functions deployment and owner access."
                        busy = false
                    }
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "CREATING…" else "CREATE MEMBER") }
                if (status.isNotBlank()) Text(status, color = Gold)
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Muted)
            Spacer(Modifier.width(12.dp))
            Text(value, color = if (label == "Fee status" && value == "PAID") Gold else Color.White, fontWeight = FontWeight.SemiBold)
        }
    }
}
