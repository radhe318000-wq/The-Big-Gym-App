# One-time owner account setup (trusted environment only)

Do not implement this step inside the Android app.

1. Create an owner account in Firebase Authentication (Email/Password).
2. From a trusted Admin SDK environment (for example, a local script using a service account stored securely), set a custom claim:
   `await admin.auth().setCustomUserClaims(OWNER_UID, { role: "owner" });`
3. Sign out and sign in again on the Android app so the fresh ID token includes the owner claim.
4. Never ship the service-account JSON with the app or share it in chat.

For local Firebase CLI deployment:
- `cd firebase/functions`
- `npm install`
- `firebase deploy --only functions,firestore:rules`

Set up Firebase CLI in the project root and select the correct Firebase project before deploying.
