const { onCall, HttpsError } = require("firebase-functions/v2/https");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();
const auth = admin.auth();

function requireOwner(request) {
  if (!request.auth || request.auth.token.role !== "owner") {
    throw new HttpsError("permission-denied", "Owner access required.");
  }
}

function memberEmail(id) {
  return `${id.toLowerCase()}@members.thebiggym.app`;
}

exports.createMember = onCall(async (request) => {
  requireOwner(request);
  const d = request.data || {};
  const name = String(d.name || "").trim();
  const password = String(d.password || "");
  const feeAmount = Number(d.feeAmount);

  if (!name || password.length < 8 || !Number.isFinite(feeAmount) || feeAmount < 0) {
    throw new HttpsError("invalid-argument", "Name, valid fee, and password (8+ chars) are required.");
  }

  const counterRef = db.doc("counters/members");
  const membershipId = await db.runTransaction(async (tx) => {
    const snap = await tx.get(counterRef);
    const next = (snap.exists ? Number(snap.data().next || 1) : 1);
    tx.set(counterRef, { next: next + 1 }, { merge: true });
    return `TBG-${String(next).padStart(4, "0")}`;
  });

  let user;
  try {
    user = await auth.createUser({
      email: memberEmail(membershipId),
      password,
      displayName: name,
      disabled: false
    });
    await auth.setCustomUserClaims(user.uid, { role: "member" });
    await db.doc(`members/${user.uid}`).set({
      membershipId,
      name,
      phone: String(d.phone || "").trim(),
      plan: String(d.plan || "Monthly").trim(),
      feeAmount,
      joiningDate: String(d.joiningDate || "").trim(),
      expiryDate: String(d.expiryDate || "").trim(),
      feeStatus: "pending",
      status: "active",
      role: "member",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    return { membershipId, uid: user.uid };
  } catch (e) {
    if (user) await auth.deleteUser(user.uid).catch(() => {});
    throw new HttpsError("internal", "Could not create member account.");
  }
});

exports.getMemberForOwner = onCall(async (request) => {
  requireOwner(request);
  const id = String((request.data || {}).membershipId || "").trim().toUpperCase();
  if (!/^TBG-\d{4,}$/.test(id)) throw new HttpsError("invalid-argument", "Invalid Membership ID.");
  const snap = await db.collection("members").where("membershipId", "==", id).limit(1).get();
  if (snap.empty) return { uid: null };
  return { uid: snap.docs[0].id };
});

exports.markFeesPaid = onCall(async (request) => {
  requireOwner(request);
  const d = request.data || {};
  const id = String(d.membershipId || "").trim().toUpperCase();
  const amount = Number(d.amount);
  const method = String(d.method || "BharatPe/UPI");
  if (!/^TBG-\d{4,}$/.test(id) || !Number.isFinite(amount) || amount < 0) {
    throw new HttpsError("invalid-argument", "Invalid membership ID or amount.");
  }
  const snap = await db.collection("members").where("membershipId", "==", id).limit(1).get();
  if (snap.empty) throw new HttpsError("not-found", "Member not found.");
  const memberDoc = snap.docs[0];
  const paymentRef = db.collection("payments").doc();
  await db.runTransaction(async (tx) => {
    tx.update(memberDoc.ref, {
      feeStatus: "paid",
      lastPaymentAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    tx.set(paymentRef, {
      memberUid: memberDoc.id,
      membershipId: id,
      amount,
      method,
      status: "verified_by_owner",
      verifiedBy: request.auth.uid,
      paidAt: admin.firestore.FieldValue.serverTimestamp()
    });
  });
  return { ok: true, paymentId: paymentRef.id };
});
